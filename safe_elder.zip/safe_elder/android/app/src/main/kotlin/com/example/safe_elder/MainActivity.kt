package com.example.safe_elder

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
